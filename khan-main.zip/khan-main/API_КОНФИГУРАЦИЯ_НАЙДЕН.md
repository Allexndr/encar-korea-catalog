# ✅ НАЙДЕНЫ API ДЛЯ ДЕТАЛЬНОЙ КОНФИГУРАЦИИ!

## 🎯 Два API эндпоинта:

### 1. Параметры машины (основные характеристики)

**URL:**
```
https://cacheapigo.che168.com/CarProduct/GetParam.ashx?specid={specid}
```

**Параметры:**
- `specid` - ID спецификации (можно получить из основного API: `result.specid`)

**Пример:**
```
https://cacheapigo.che168.com/CarProduct/GetParam.ashx?specid=54817
```

**Что возвращает:**
- Название модели
- Рекомендованная цена производителя (24.99万)
- Производитель (一汽-大众 / FAW-Volkswagen)
- Уровень (中型SUV / Среднеразмерный внедорожник)
- Тип энергии (汽油 / Бензин)
- Экологические стандарты (国VI)
- Дата запуска (2021.12)
- **Мощность: 162 кВт**
- **Крутящий момент: 350 Н·м**
- **Двигатель: 2.0T 220 л.с. L4**
- **Коробка передач: 7-ступенчатая**
- **Размеры: 4589*1860*1660 мм**
- **Максимальная скорость: 200 км/ч**
- **Ускорение 0-100: 7.6 с**
- **Расход топлива: 7.5 л/100 км (NEDC)**

---

### 2. Полная конфигурация (все опции)

**URL:**
```
https://cacheapi.che168.com/CarProduct/GetSpecListConfig.ashx?specid={specid}
```

**Параметры:**
- `specid` - ID спецификации

**Пример:**
```
https://cacheapi.che168.com/CarProduct/GetSpecListConfig.ashx?specid=54817
```

**Что возвращает:**
- Все категории конфигурации:
  - Основные параметры
  - Кузов
  - Двигатель (детали)
  - Коробка передач
  - Рулевое управление
  - Торможение
  - Безопасность (пассивная/активная)
  - Функции вождения
  - Внешний вид/Интерьер
- Детальные опции по каждой категории

---

## 📋 Как использовать:

### Шаг 1: Получить specid из основного API

```bash
curl "https://apipcmusc.che168.com/v1/car/getcarinfo?_appid=2sc.pc&infoid=56635701"
```

В ответе будет `"specid": 54817`

### Шаг 2: Получить параметры

```bash
curl "https://cacheapigo.che168.com/CarProduct/GetParam.ashx?specid=54817"
```

### Шаг 3: Получить полную конфигурацию

```bash
curl "https://cacheapi.che168.com/CarProduct/GetSpecListConfig.ashx?specid=54817"
```

---

## 🔍 Где нашел:

В JavaScript файле страницы конфигурации:
`//x.autoimg.cn/com/co.ashx?path=/2sc/pc/CarConfig/CarConfig.js`

Найдены строки:
```javascript
var paramUrl = "//cacheapigo.che168.com/CarProduct/GetParam.ashx?specid=" + carinfo.specid;
var configUrl = "//cacheapi.che168.com/CarProduct/GetSpecListConfig.ashx?specid=" + carinfo.specid;
```

---

## ✅ ИТОГ:

**Все данные с скриншотов ЕСТЬ в этих API!**

- ✅ Модель двигателя (EA888-DKX) - в полной конфигурации
- ✅ Объем в мл (1984) - в полной конфигурации  
- ✅ Все детали двигателя, коробки, размеры, скорость, расход - ВСЁ ЕСТЬ!


